
const express = require('express');
const fs = require('fs');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

const usuariosPath = './backend/usuarios.csv';
const produtosPath = './backend/produtos.csv';

// Função para ler CSV
function readCSV(path) {
    const data = fs.readFileSync(path, 'utf8');
    const lines = data.trim().split('\n');
    const headers = lines[0].split(',');
    return lines.slice(1).map(line => {
        const values = line.split(',');
        return Object.fromEntries(headers.map((h, i) => [h, values[i]]));
    });
}

// Função para escrever CSV
function writeCSV(path, data) {
    const headers = Object.keys(data[0]);
    const lines = data.map(row => headers.map(h => row[h]).join(','));
    fs.writeFileSync(path, headers.join(',') + '\n' + lines.join('\n'), 'utf8');
}

// Registro
app.post('/register', (req, res) => {
    const { nome, email, senha } = req.body;
    let usuarios = readCSV(usuariosPath);
    if (usuarios.find(u => u.email === email)) {
        return res.status(400).json({ msg: 'Email já registrado.' });
    }
    const novoUsuario = {
        id: usuarios.length + 1 + '',
        nome,
        email,
        senha,
        tipo: 'cliente'
    };
    usuarios.push(novoUsuario);
    writeCSV(usuariosPath, usuarios);
    res.json({ msg: 'Registrado com sucesso!' });
});

// Login
app.post('/login', (req, res) => {
    const { email, senha } = req.body;
    const usuarios = readCSV(usuariosPath);
    const user = usuarios.find(u => u.email === email && u.senha === senha);
    if (!user) return res.status(401).json({ msg: 'Credenciais inválidas' });
    res.json(user);
});

// Obter produtos
app.get('/produtos', (req, res) => {
    const produtos = readCSV(produtosPath);
    res.json(produtos);
});

// Adicionar produto (admin)
app.post('/produtos', (req, res) => {
    const { nome, tipo, descricao, preco, imagem } = req.body;
    let produtos = readCSV(produtosPath);
    const novo = {
        id: produtos.length + 1 + '',
        nome,
        tipo,
        descricao,
        preco,
        imagem
    };
    produtos.push(novo);
    writeCSV(produtosPath, produtos);
    res.json({ msg: 'Produto adicionado.' });
});

// Atualizar produto
app.put('/produtos/:id', (req, res) => {
    const { id } = req.params;
    let produtos = readCSV(produtosPath);
    produtos = produtos.map(p => p.id === id ? { ...p, ...req.body } : p);
    writeCSV(produtosPath, produtos);
    res.json({ msg: 'Produto atualizado.' });
});

// Remover produto
app.delete('/produtos/:id', (req, res) => {
    const { id } = req.params;
    let produtos = readCSV(produtosPath);
    produtos = produtos.filter(p => p.id !== id);
    writeCSV(produtosPath, produtos);
    res.json({ msg: 'Produto removido.' });
});

// Listar usuários (admin)
app.get('/usuarios', (req, res) => {
    const usuarios = readCSV(usuariosPath);
    res.json(usuarios);
});

// Promover usuário
app.put('/usuarios/:id', (req, res) => {
    const { id } = req.params;
    let usuarios = readCSV(usuariosPath);
    usuarios = usuarios.map(u => u.id === id ? { ...u, ...req.body } : u);
    writeCSV(usuariosPath, usuarios);
    res.json({ msg: 'Usuário atualizado.' });
});

app.listen(PORT, () => {
    console.log('Servidor rodando na porta', PORT);
});
