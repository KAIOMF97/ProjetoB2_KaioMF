// Variáveis globais
let allProducts = [];
let editingProductId = null;

// Função para mostrar mensagens no formulário
function showFormMessage(message, type = 'info') {
  const messageDiv = document.getElementById('formMessage');
  if (messageDiv) {
    messageDiv.textContent = message;
    messageDiv.className = `message ${type}`;
    messageDiv.style.display = 'block';
    
    setTimeout(() => {
      messageDiv.style.display = 'none';
    }, 5000);
  }
}

// Verificar se o usuário é admin
function checkAdminAccess() {
  if (!isLoggedIn()) {
    window.location.href = 'login.html';
    return false;
  }
  
  if (!isAdmin()) {
    alert('Acesso negado. Apenas administradores podem acessar esta página.');
    window.location.href = 'index.html';
    return false;
  }
  
  return true;
}

// Carregar produtos da API
async function loadProducts() {
  try {
    const products = await apiRequest('/products');
    allProducts = products;
    displayProducts(products);
  } catch (error) {
    console.error('Erro ao carregar produtos:', error);
    showFormMessage('Erro ao carregar produtos: ' + error.message, 'error');
  }
}

// Exibir produtos na grade
function displayProducts(products) {
  const productsGrid = document.getElementById('productsGrid');
  
  if (products.length === 0) {
    productsGrid.innerHTML = '<p>Nenhum produto encontrado.</p>';
    return;
  }
  
  productsGrid.innerHTML = products.map(product => `
    <div class="product-card">
      <img src="${product.image}" alt="${product.name}" onerror="this.src='imagens/logo.png'">
      <h4>${product.name}</h4>
      <p><strong>Preço:</strong> R$ ${parseFloat(product.price).toFixed(2)}</p>
      <p><strong>Categoria:</strong> ${product.category}</p>
      <div class="product-actions">
        <button class="btn-edit" onclick="editProduct(${product.id})">Editar</button>
        <button class="btn-delete" onclick="deleteProduct(${product.id})">Excluir</button>
      </div>
    </div>
  `).join('');
}

// Filtrar produtos por categoria
function filterProducts() {
  const categoryFilter = document.getElementById('categoryFilter').value;
  
  if (categoryFilter === '') {
    displayProducts(allProducts);
  } else {
    const filteredProducts = allProducts.filter(product => product.category === categoryFilter);
    displayProducts(filteredProducts);
  }
}

// Manipulador do formulário de produto
document.addEventListener('DOMContentLoaded', function() {
  // Verificar acesso admin
  if (!checkAdminAccess()) {
    return;
  }
  
  // Atualizar nome do admin
  const user = getCurrentUser();
  const adminNameSpan = document.getElementById('adminName');
  if (adminNameSpan && user) {
    adminNameSpan.textContent = user.name;
  }
  
  // Carregar produtos
  loadProducts();
  
  // Configurar formulário
  const productForm = document.getElementById('productForm');
  if (productForm) {
    productForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const formData = new FormData(productForm);
      const productData = {
        name: formData.get('productName'),
        price: parseFloat(formData.get('productPrice')),
        category: formData.get('productCategory'),
        image: formData.get('productImage')
      };
      
      try {
        if (editingProductId) {
          // Editar produto existente
          showFormMessage('Atualizando produto...', 'info');
          await apiRequest(`/products/${editingProductId}`, {
            method: 'PUT',
            body: JSON.stringify(productData)
          });
          showFormMessage('Produto atualizado com sucesso!', 'success');
          cancelEdit();
        } else {
          // Adicionar novo produto
          showFormMessage('Adicionando produto...', 'info');
          await apiRequest('/products', {
            method: 'POST',
            body: JSON.stringify(productData)
          });
          showFormMessage('Produto adicionado com sucesso!', 'success');
          productForm.reset();
        }
        
        // Recarregar produtos
        await loadProducts();
        
      } catch (error) {
        showFormMessage('Erro: ' + error.message, 'error');
      }
    });
  }
});

// Editar produto
function editProduct(productId) {
  const product = allProducts.find(p => p.id == productId);
  if (!product) {
    showFormMessage('Produto não encontrado', 'error');
    return;
  }
  
  // Preencher formulário
  document.getElementById('productId').value = product.id;
  document.getElementById('productName').value = product.name;
  document.getElementById('productPrice').value = product.price;
  document.getElementById('productCategory').value = product.category;
  document.getElementById('productImage').value = product.image;
  
  // Atualizar interface
  document.getElementById('formTitle').textContent = 'Editar Produto';
  document.getElementById('submitBtn').textContent = 'Atualizar Produto';
  document.getElementById('cancelBtn').style.display = 'inline-block';
  
  editingProductId = productId;
  
  // Scroll para o formulário
  document.getElementById('productForm').scrollIntoView({ behavior: 'smooth' });
}

// Cancelar edição
function cancelEdit() {
  editingProductId = null;
  
  // Limpar formulário
  document.getElementById('productForm').reset();
  document.getElementById('productId').value = '';
  
  // Restaurar interface
  document.getElementById('formTitle').textContent = 'Adicionar Novo Produto';
  document.getElementById('submitBtn').textContent = 'Adicionar Produto';
  document.getElementById('cancelBtn').style.display = 'none';
}

// Excluir produto
async function deleteProduct(productId) {
  const product = allProducts.find(p => p.id == productId);
  if (!product) {
    showFormMessage('Produto não encontrado', 'error');
    return;
  }
  
  if (!confirm(`Tem certeza que deseja excluir o produto "${product.name}"?`)) {
    return;
  }
  
  try {
    showFormMessage('Excluindo produto...', 'info');
    await apiRequest(`/products/${productId}`, {
      method: 'DELETE'
    });
    
    showFormMessage('Produto excluído com sucesso!', 'success');
    
    // Recarregar produtos
    await loadProducts();
    
    // Se estava editando este produto, cancelar edição
    if (editingProductId == productId) {
      cancelEdit();
    }
    
  } catch (error) {
    showFormMessage('Erro ao excluir produto: ' + error.message, 'error');
  }
}

