// Configuração da API
const API_BASE = 'http://localhost:3000/api';

// Função para mostrar mensagens
function showMessage(message, type = 'info') {
  const messageDiv = document.getElementById('message');
  if (messageDiv) {
    messageDiv.textContent = message;
    messageDiv.className = `message ${type}`;
    messageDiv.style.display = 'block';
    
    setTimeout(() => {
      messageDiv.style.display = 'none';
    }, 5000);
  }
}

// Função para fazer requisições à API
async function apiRequest(endpoint, options = {}) {
  try {
    const token = localStorage.getItem('token');
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers
    };
    
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }
    
    const response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Erro na requisição');
    }
    
    return data;
  } catch (error) {
    console.error('Erro na API:', error);
    throw error;
  }
}

// Função para verificar se o usuário está logado
function isLoggedIn() {
  return localStorage.getItem('token') !== null;
}

// Função para obter dados do usuário
function getCurrentUser() {
  const userStr = localStorage.getItem('user');
  return userStr ? JSON.parse(userStr) : null;
}

// Função para fazer logout
function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  window.location.href = 'index.html';
}

// Função para verificar se é admin
function isAdmin() {
  const user = getCurrentUser();
  return user && user.role === 'admin';
}

// Manipulador do formulário de login
document.addEventListener('DOMContentLoaded', function() {
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  
  if (loginForm) {
    loginForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      
      try {
        showMessage('Fazendo login...', 'info');
        
        const response = await apiRequest('/login', {
          method: 'POST',
          body: JSON.stringify({ email, password })
        });
        
        localStorage.setItem('token', response.token);
        localStorage.setItem('user', JSON.stringify(response.user));
        
        showMessage('Login realizado com sucesso!', 'success');
        
        setTimeout(() => {
          window.location.href = 'index.html';
        }, 1000);
        
      } catch (error) {
        showMessage(error.message, 'error');
      }
    });
  }
  
  if (registerForm) {
    registerForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirmPassword').value;
      
      if (password !== confirmPassword) {
        showMessage('As senhas não coincidem', 'error');
        return;
      }
      
      if (password.length < 6) {
        showMessage('A senha deve ter pelo menos 6 caracteres', 'error');
        return;
      }
      
      try {
        showMessage('Criando conta...', 'info');
        
        await apiRequest('/register', {
          method: 'POST',
          body: JSON.stringify({ name, email, password })
        });
        
        showMessage('Conta criada com sucesso! Redirecionando para login...', 'success');
        
        setTimeout(() => {
          window.location.href = 'login.html';
        }, 2000);
        
      } catch (error) {
        showMessage(error.message, 'error');
      }
    });
  }
});

// Função para atualizar a interface baseada no estado de login
function updateAuthUI() {
  const authButtons = document.querySelector('.auth-buttons');
  const userInfo = document.querySelector('.user-info');
  
  if (isLoggedIn()) {
    const user = getCurrentUser();
    
    if (authButtons) {
      authButtons.innerHTML = `
        <div class="user-info">
          <span>Olá, ${user.name}</span>
          ${user.role === 'admin' ? '<a href="admin.html" class="btn-auth admin-btn">Admin</a>' : ''}
          <button onclick="logout()" class="btn-auth logout-btn">Sair</button>
        </div>
      `;
    }
  } else {
    if (authButtons) {
      authButtons.innerHTML = `
        <a href="login.html" class="btn-auth">Login</a>
        <a href="cadastro.html" class="btn-auth">Cadastrar</a>
      `;
    }
  }
}

// Verificar autenticação ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
  updateAuthUI();
});

