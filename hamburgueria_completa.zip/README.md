# Sistema de Hamburgueria com Autenticação

Este projeto implementa um sistema completo de hamburgueria com autenticação de usuários e painel administrativo.

## Funcionalidades Implementadas

### 🔐 Sistema de Autenticação
- **Login de Cliente**: Usuários podem criar conta e fazer login
- **Login de Admin**: Administradores têm acesso especial ao sistema
- **Cadastro**: Formulário de registro para novos usuários
- **Controle de Acesso**: Carrinho e funcionalidades de compra requerem login

### 👨‍💼 Painel Administrativo
- **CRUD de Produtos**: Adicionar, editar e remover produtos
- **Gerenciamento por Categoria**: Hambúrgueres, bebidas e sobremesas
- **Interface Intuitiva**: Formulários e listagem de produtos
- **Filtros**: Visualização por categoria

### 🛒 Sistema de Compras
- **Catálogo de Produtos**: Carregamento dinâmico da API
- **Carrinho de Compras**: Apenas para usuários logados
- **Cálculo de Subtotal**: Atualização em tempo real
- **Pesquisa**: Busca por nome de produto

## Tecnologias Utilizadas

### Backend
- **Node.js**: Servidor principal
- **Express**: Framework web
- **JWT**: Autenticação por tokens
- **bcryptjs**: Criptografia de senhas
- **CSV**: Armazenamento de dados em arquivos CSV
- **CORS**: Habilitado para requisições cross-origin

### Frontend
- **HTML5**: Estrutura das páginas
- **CSS3**: Estilização responsiva
- **JavaScript**: Interatividade e comunicação com API
- **Fetch API**: Requisições HTTP

## Estrutura de Arquivos

```
projeto/
├── server.js              # Servidor Node.js principal
├── package.json           # Dependências do projeto
├── users.csv             # Banco de dados de usuários
├── products.csv          # Banco de dados de produtos
├── index.html            # Página principal
├── login.html            # Página de login
├── cadastro.html         # Página de cadastro
├── admin.html            # Painel administrativo
├── carrinho.html         # Página do carrinho
├── pagamento.html        # Página de pagamento
├── produtos.html         # Página de produtos
├── script.js             # Script principal do frontend
├── auth.js               # Script de autenticação
├── admin.js              # Script do painel admin
├── carrinho.js           # Script do carrinho
├── style.css             # Estilos CSS
└── imagens/              # Pasta com imagens dos produtos
```

## Como Executar

### 1. Instalar Dependências
```bash
npm install
```

### 2. Iniciar o Servidor
```bash
npm start
```

### 3. Acessar o Sistema
- Abra o navegador em: `http://localhost:3000`
- Para acessar como admin use:
  - Email: `admin@hamburgueria.com`
  - Senha: `admin123`

## API Endpoints

### Autenticação
- `POST /api/register` - Cadastrar novo usuário
- `POST /api/login` - Fazer login
- `GET /api/verify-token` - Verificar token válido

### Produtos (Admin apenas)
- `GET /api/products` - Listar todos os produtos
- `POST /api/products` - Adicionar novo produto
- `PUT /api/products/:id` - Editar produto
- `DELETE /api/products/:id` - Remover produto

## Diferenças entre Cliente e Admin

### Cliente
- Pode navegar pelos produtos
- Pode adicionar itens ao carrinho (apenas logado)
- Pode fazer pedidos
- Não tem acesso ao painel administrativo

### Admin
- Todas as funcionalidades do cliente
- Acesso ao painel administrativo
- Pode adicionar, editar e remover produtos
- Botão "Admin" aparece no header quando logado

## Segurança

- Senhas são criptografadas com bcrypt
- Autenticação via JWT tokens
- Verificação de permissões no backend
- Validação de dados nos formulários
- Controle de acesso baseado em roles

## Armazenamento de Dados

Os dados são armazenados em arquivos CSV:

### users.csv
- ID, EMAIL, PASSWORD (criptografada), NAME, ROLE

### products.csv  
- ID, NAME, PRICE, IMAGE, CATEGORY

## Responsividade

O sistema é totalmente responsivo e funciona em:
- Desktop
- Tablets
- Smartphones

## Próximas Melhorias

- Integração com gateway de pagamento
- Sistema de pedidos completo
- Relatórios administrativos
- Upload de imagens para produtos
- Sistema de avaliações

