const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const csv = require('csv-parser');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

const app = express();
const PORT = 3000;
const JWT_SECRET = 'hamburgueria_secret_key_2024';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Caminhos dos arquivos CSV
const USERS_CSV = path.join(__dirname, 'users.csv');
const PRODUCTS_CSV = path.join(__dirname, 'products.csv');

// Inicializar arquivos CSV se não existirem
function initializeCSVFiles() {
  // Arquivo de usuários
  if (!fs.existsSync(USERS_CSV)) {
    const usersCsvWriter = createCsvWriter({
      path: USERS_CSV,
      header: [
        { id: 'id', title: 'ID' },
        { id: 'email', title: 'EMAIL' },
        { id: 'password', title: 'PASSWORD' },
        { id: 'name', title: 'NAME' },
        { id: 'role', title: 'ROLE' }
      ]
    });
    
    // Criar admin padrão
    const adminPassword = bcrypt.hashSync('admin123', 10);
    usersCsvWriter.writeRecords([
      { id: 1, email: 'admin@hamburgueria.com', password: adminPassword, name: 'Administrador', role: 'admin' }
    ]);
  }

  // Arquivo de produtos
  if (!fs.existsSync(PRODUCTS_CSV)) {
    const productsCsvWriter = createCsvWriter({
      path: PRODUCTS_CSV,
      header: [
        { id: 'id', title: 'ID' },
        { id: 'name', title: 'NAME' },
        { id: 'price', title: 'PRICE' },
        { id: 'image', title: 'IMAGE' },
        { id: 'category', title: 'CATEGORY' }
      ]
    });
    
    // Produtos iniciais baseados no script.js
    const initialProducts = [
      // Hambúrgueres
      { id: 1, name: "Clássico", price: 18, image: "imagens/classico.jpg", category: "hamburgueres" },
      { id: 2, name: "Cheddar Bacon", price: 22, image: "imagens/cheddar.jpg", category: "hamburgueres" },
      { id: 3, name: "Duplo", price: 25, image: "imagens/duplo.jpg", category: "hamburgueres" },
      { id: 4, name: "Frango Crocante", price: 20, image: "imagens/frangocro.jpg", category: "hamburgueres" },
      { id: 5, name: "Vegano", price: 21, image: "imagens/vegano.jpg", category: "hamburgueres" },
      { id: 6, name: "Barbecue", price: 23, image: "imagens/barbecue.jpg", category: "hamburgueres" },
      { id: 7, name: "Egg Burger", price: 19, image: "imagens/egg.jpg", category: "hamburgueres" },
      { id: 8, name: "Blue Cheese", price: 26, image: "imagens/bluecheese.jpg", category: "hamburgueres" },
      { id: 9, name: "Chili Burger", price: 24, image: "imagens/chili.jpg", category: "hamburgueres" },
      { id: 10, name: "Picanha", price: 28, image: "imagens/picanha.jpg", category: "hamburgueres" },
      { id: 11, name: "Costela", price: 30, image: "imagens/costela.jpg", category: "hamburgueres" },
      { id: 12, name: "Smash Burger", price: 18, image: "imagens/smash.jpg", category: "hamburgueres" },
      { id: 13, name: "Onion Burger", price: 21, image: "imagens/onion.jpg", category: "hamburgueres" },
      { id: 14, name: "Molho da Casa", price: 22, image: "imagens/molho.jpg", category: "hamburgueres" },
      { id: 15, name: "Texano", price: 27, image: "imagens/texano.jpg", category: "hamburgueres" },
      { id: 16, name: "Trufado", price: 32, image: "imagens/trufado.jpg", category: "hamburgueres" },
      
      // Bebidas
      { id: 17, name: "Refrigerante Lata", price: 6, image: "imagens/coca.png", category: "bebidas" },
      { id: 18, name: "Suco Natural", price: 8, image: "imagens/suco.png", category: "bebidas" },
      { id: 19, name: "Água Mineral", price: 4, image: "imagens/agua.png", category: "bebidas" },
      { id: 20, name: "Cerveja Artesanal", price: 12, image: "imagens/cerveja.png", category: "bebidas" },
      { id: 21, name: "Milkshake", price: 14, image: "imagens/milkshake.png", category: "bebidas" },
      { id: 22, name: "Chá Gelado", price: 7, image: "imagens/cha.png", category: "bebidas" },
      
      // Sobremesas
      { id: 23, name: "Brownie", price: 10, image: "imagens/brownie.png", category: "sobremesas" },
      { id: 24, name: "Sorvete", price: 8, image: "imagens/sorvete.png", category: "sobremesas" },
      { id: 25, name: "Torta de Chocolate", price: 12, image: "imagens/tortachocolate.png", category: "sobremesas" },
      { id: 26, name: "Petit Gateau", price: 15, image: "imagens/petit.png", category: "sobremesas" },
      { id: 27, name: "Mousse", price: 9, image: "imagens/mousse.png", category: "sobremesas" }
    ];
    
    productsCsvWriter.writeRecords(initialProducts);
  }
}

// Funções auxiliares para CSV
function readUsersFromCSV() {
  return new Promise((resolve, reject) => {
    const users = [];
    fs.createReadStream(USERS_CSV)
      .pipe(csv())
      .on('data', (data) => users.push(data))
      .on('end', () => resolve(users))
      .on('error', reject);
  });
}

function readProductsFromCSV() {
  return new Promise((resolve, reject) => {
    const products = [];
    fs.createReadStream(PRODUCTS_CSV)
      .pipe(csv())
      .on('data', (data) => {
        data.price = parseFloat(data.price);
        data.id = parseInt(data.id);
        products.push(data);
      })
      .on('end', () => resolve(products))
      .on('error', reject);
  });
}

function writeUsersToCSV(users) {
  const usersCsvWriter = createCsvWriter({
    path: USERS_CSV,
    header: [
      { id: 'id', title: 'ID' },
      { id: 'email', title: 'EMAIL' },
      { id: 'password', title: 'PASSWORD' },
      { id: 'name', title: 'NAME' },
      { id: 'role', title: 'ROLE' }
    ]
  });
  return usersCsvWriter.writeRecords(users);
}

function writeProductsToCSV(products) {
  const productsCsvWriter = createCsvWriter({
    path: PRODUCTS_CSV,
    header: [
      { id: 'id', title: 'ID' },
      { id: 'name', title: 'NAME' },
      { id: 'price', title: 'PRICE' },
      { id: 'image', title: 'IMAGE' },
      { id: 'category', title: 'CATEGORY' }
    ]
  });
  return productsCsvWriter.writeRecords(products);
}

// Middleware de autenticação
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token de acesso requerido' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Token inválido' });
    }
    req.user = user;
    next();
  });
}

// Middleware para verificar se é admin
function requireAdmin(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Acesso negado. Apenas administradores.' });
  }
  next();
}

// Rotas de autenticação
app.post('/api/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    
    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }

    const users = await readUsersFromCSV();
    
    // Verificar se usuário já existe
    if (users.find(user => user.email === email)) {
      return res.status(400).json({ error: 'Email já cadastrado' });
    }

    // Criar novo usuário
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = {
      id: users.length + 1,
      email,
      password: hashedPassword,
      name,
      role: 'client'
    };

    users.push(newUser);
    await writeUsersToCSV(users);

    res.status(201).json({ message: 'Usuário cadastrado com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Email e senha são obrigatórios' });
    }

    const users = await readUsersFromCSV();
    const user = users.find(u => u.email === email);

    if (!user || !await bcrypt.compare(password, user.password)) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Rota para verificar token
app.get('/api/verify-token', authenticateToken, (req, res) => {
  res.json({ user: req.user });
});

// Rotas de produtos
app.get('/api/products', async (req, res) => {
  try {
    const products = await readProductsFromCSV();
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao carregar produtos' });
  }
});

app.post('/api/products', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { name, price, image, category } = req.body;
    
    if (!name || !price || !image || !category) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }

    const products = await readProductsFromCSV();
    const newProduct = {
      id: Math.max(...products.map(p => p.id), 0) + 1,
      name,
      price: parseFloat(price),
      image,
      category
    };

    products.push(newProduct);
    await writeProductsToCSV(products);

    res.status(201).json(newProduct);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao adicionar produto' });
  }
});

app.put('/api/products/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, price, image, category } = req.body;
    
    const products = await readProductsFromCSV();
    const productIndex = products.findIndex(p => p.id == id);
    
    if (productIndex === -1) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    products[productIndex] = {
      ...products[productIndex],
      name: name || products[productIndex].name,
      price: price ? parseFloat(price) : products[productIndex].price,
      image: image || products[productIndex].image,
      category: category || products[productIndex].category
    };

    await writeProductsToCSV(products);
    res.json(products[productIndex]);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar produto' });
  }
});

app.delete('/api/products/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    
    const products = await readProductsFromCSV();
    const filteredProducts = products.filter(p => p.id != id);
    
    if (products.length === filteredProducts.length) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    await writeProductsToCSV(filteredProducts);
    res.json({ message: 'Produto removido com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao remover produto' });
  }
});

// Inicializar arquivos CSV e iniciar servidor
initializeCSVFiles();

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});

